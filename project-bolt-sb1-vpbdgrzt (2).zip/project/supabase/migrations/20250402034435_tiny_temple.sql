/*
  # Add Profile Fields

  1. Changes to Existing Tables
    - Add to `profiles` table:
      - `gender` (text)
      - `avatar_url` (text)
      - `walking_goal` (integer, default 10000)

  2. Security
    - Existing RLS policies will cover the new fields
*/

ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS gender text,
ADD COLUMN IF NOT EXISTS avatar_url text,
ADD COLUMN IF NOT EXISTS walking_goal integer DEFAULT 10000;